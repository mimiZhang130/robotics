
from asn1_turn_right import turnRight90
import argparse
import time

if __name__ == '__main__':  
    turnRight90()
    turnRight90()