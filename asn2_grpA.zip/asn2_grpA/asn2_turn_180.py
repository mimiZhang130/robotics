from asn2_turn_right import turnRight90

def turn180():
    turnRight90()
    turnRight90()

if __name__ == '__main__':  
    turn180()